"""Market data: real Binance candles, or synthetic candles for offline testing."""
from __future__ import annotations

import threading
import time
import zlib

import numpy as np
import pandas as pd
from scipy.signal import lfilter

TF_SECONDS = {"1m": 60, "3m": 180, "5m": 300, "15m": 900, "30m": 1800, "1h": 3600}
COLUMNS = ["ts", "open", "high", "low", "close", "volume"]


class BinanceData:
    """Public Binance market data (no API key needed)."""

    def __init__(self):
        import ccxt

        self.ex = ccxt.binance({"enableRateLimit": True, "options": {"defaultType": "spot"}})
        self._lock = threading.Lock()

    def ohlcv(self, symbol: str, timeframe: str, limit: int = 1000) -> pd.DataFrame:
        with self._lock:
            raw = self.ex.fetch_ohlcv(symbol, timeframe, limit=limit)
        return pd.DataFrame(raw, columns=COLUMNS)

    def price(self, symbol: str) -> float:
        with self._lock:
            return float(self.ex.fetch_ticker(symbol)["last"])


class SyntheticData:
    """Fake but repeatable price series. ONLY for testing the software without internet."""

    T0 = 1_704_067_200  # 2024-01-01 UTC
    BASES = {"BTC": 60000.0, "ETH": 3000.0, "BNB": 600.0, "SOL": 150.0}

    def __init__(self):
        self._cache: dict = {}

    def _series(self, symbol: str, tf_s: int, need: int):
        key = (symbol, tf_s)
        cached = self._cache.get(key)
        if cached is not None and cached["n"] > need:
            return cached
        n = need + 20_000
        seed = zlib.crc32(symbol.encode())
        rng = np.random.default_rng(seed)
        z = rng.standard_normal(n)
        idx = np.arange(n)
        vol = 0.0025 * np.sqrt(tf_s / 900) * (1 + 0.4 * np.sin(idx / 300.0 + seed % 7))
        ret = lfilter([1.0], [1.0, -0.12], z * vol) + 0.00002 * np.sin(idx / 900.0)
        base = self.BASES.get(symbol.split("/")[0], 100.0)
        close = base * np.exp(np.cumsum(ret))
        open_ = np.concatenate([[base], close[:-1]])
        high = np.maximum(open_, close) * (1 + np.abs(rng.standard_normal(n)) * vol * 0.5)
        low = np.minimum(open_, close) * (1 - np.abs(rng.standard_normal(n)) * vol * 0.5)
        volume = rng.lognormal(3.0, 0.5, n) * (1 + np.abs(z))
        self._cache[key] = {"n": n, "o": open_, "h": high, "l": low, "c": close, "v": volume}
        return self._cache[key]

    def _current_index(self, tf_s: int):
        now = time.time()
        i = int((now - self.T0) // tf_s)
        frac = (now - (self.T0 + i * tf_s)) / tf_s
        return i, frac

    def ohlcv(self, symbol: str, timeframe: str, limit: int = 1000) -> pd.DataFrame:
        tf_s = TF_SECONDS[timeframe]
        i, frac = self._current_index(tf_s)
        s = self._series(symbol, tf_s, i + 5)
        lo = i - limit + 1
        sl = slice(lo, i + 1)
        df = pd.DataFrame(
            {
                "ts": (self.T0 + np.arange(lo, i + 1) * tf_s) * 1000,
                "open": s["o"][sl].copy(),
                "high": s["h"][sl].copy(),
                "low": s["l"][sl].copy(),
                "close": s["c"][sl].copy(),
                "volume": s["v"][sl].copy(),
            }
        )
        # the last candle is still "forming", like on Binance
        o, c = df.at[len(df) - 1, "open"], df.at[len(df) - 1, "close"]
        cp = o + (c - o) * frac
        df.at[len(df) - 1, "close"] = cp
        df.at[len(df) - 1, "high"] = max(o, cp) * (1 + (df.at[len(df) - 1, "high"] / max(o, c) - 1) * frac)
        df.at[len(df) - 1, "low"] = min(o, cp) * (1 - (1 - df.at[len(df) - 1, "low"] / min(o, c)) * frac)
        return df

    def price(self, symbol: str) -> float:
        return float(self.ohlcv(symbol, "15m", 2)["close"].iloc[-1])


def make_data(source: str):
    return SyntheticData() if source == "synthetic" else BinanceData()
