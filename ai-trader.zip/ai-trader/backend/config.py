"""All settings come from environment variables / the .env file."""
from __future__ import annotations

import os
from dataclasses import asdict, dataclass
from pathlib import Path

from dotenv import load_dotenv

load_dotenv()

TIMEFRAMES = ("1m", "3m", "5m", "15m", "30m", "1h")
LIVE_PHRASE = "I_UNDERSTAND_THE_RISK"


def _e(name: str, default) -> str:
    return os.getenv(name, str(default)).strip()


@dataclass
class Config:
    mode: str
    api_key: str
    api_secret: str
    live_confirm: str
    data_source: str
    symbols: list
    timeframe: str
    loop_seconds: int
    paper_start_balance: float
    fee_rate: float
    slippage: float
    risk_per_trade: float
    max_position_pct: float
    max_open_positions: int
    atr_stop_mult: float
    take_profit_rr: float
    max_hold_candles: int
    cooldown_candles: int
    daily_loss_limit: float
    buy_threshold: float
    sell_threshold: float
    min_val_accuracy: float
    min_atr_pct: float
    trend_filter: bool
    train_candles: int
    retrain_every: int
    horizon: int
    min_notional: float
    host: str
    port: int
    state_dir: str
    auto_start: bool

    def validate(self) -> None:
        errs = []
        if self.mode not in ("paper", "testnet", "live"):
            errs.append("TRADING_MODE must be paper, testnet or live.")
        if self.data_source not in ("binance", "synthetic"):
            errs.append("DATA_SOURCE must be binance or synthetic.")
        if self.mode in ("testnet", "live"):
            if not (self.api_key and self.api_secret):
                errs.append(f"{self.mode} mode needs BINANCE_API_KEY and BINANCE_API_SECRET in .env")
            if self.data_source != "binance":
                errs.append("testnet/live modes cannot use synthetic data.")
        if self.mode == "live" and self.live_confirm != LIVE_PHRASE:
            errs.append(f"Live mode uses REAL MONEY. Set LIVE_CONFIRM={LIVE_PHRASE} in .env to allow it.")
        if self.timeframe not in TIMEFRAMES:
            errs.append(f"TIMEFRAME must be one of {TIMEFRAMES}.")
        if not self.symbols or any("/" not in s for s in self.symbols):
            errs.append("SYMBOLS must look like BTC/USDT,ETH/USDT.")
        if not 0 < self.risk_per_trade <= 0.05:
            errs.append("RISK_PER_TRADE must be between 0 and 0.05 (5%).")
        if not 0 < self.max_position_pct <= 1:
            errs.append("MAX_POSITION_PCT must be between 0 and 1.")
        if not 0 < self.daily_loss_limit <= 0.5:
            errs.append("DAILY_LOSS_LIMIT must be between 0 and 0.5.")
        if not 0.5 <= self.buy_threshold < 1:
            errs.append("BUY_THRESHOLD must be between 0.5 and 1.")
        if not 0 < self.sell_threshold < self.buy_threshold:
            errs.append("SELL_THRESHOLD must be lower than BUY_THRESHOLD.")
        if not 300 <= self.train_candles <= 1000:
            errs.append("TRAIN_CANDLES must be between 300 and 1000.")
        if errs:
            raise ValueError("\n - " + "\n - ".join(errs))

    def public(self) -> dict:
        d = asdict(self)
        for k in ("api_key", "api_secret", "live_confirm", "state_dir", "auto_start"):
            d.pop(k, None)
        return d


def load_config() -> Config:
    return Config(
        mode=_e("TRADING_MODE", "paper").lower(),
        api_key=_e("BINANCE_API_KEY", ""),
        api_secret=_e("BINANCE_API_SECRET", ""),
        live_confirm=_e("LIVE_CONFIRM", ""),
        data_source=_e("DATA_SOURCE", "binance").lower(),
        symbols=[s.strip().upper() for s in _e("SYMBOLS", "BTC/USDT,ETH/USDT").split(",") if s.strip()],
        timeframe=_e("TIMEFRAME", "15m"),
        loop_seconds=int(_e("LOOP_SECONDS", 10)),
        paper_start_balance=float(_e("PAPER_START_BALANCE", 1000)),
        fee_rate=float(_e("FEE_RATE", 0.001)),
        slippage=float(_e("SLIPPAGE", 0.0005)),
        risk_per_trade=float(_e("RISK_PER_TRADE", 0.01)),
        max_position_pct=float(_e("MAX_POSITION_PCT", 0.25)),
        max_open_positions=int(_e("MAX_OPEN_POSITIONS", 2)),
        atr_stop_mult=float(_e("ATR_STOP_MULT", 2.0)),
        take_profit_rr=float(_e("TAKE_PROFIT_RR", 2.0)),
        max_hold_candles=int(_e("MAX_HOLD_CANDLES", 12)),
        cooldown_candles=int(_e("COOLDOWN_CANDLES", 2)),
        daily_loss_limit=float(_e("DAILY_LOSS_LIMIT", 0.03)),
        buy_threshold=float(_e("BUY_THRESHOLD", 0.58)),
        sell_threshold=float(_e("SELL_THRESHOLD", 0.45)),
        min_val_accuracy=float(_e("MIN_VAL_ACCURACY", 0.52)),
        min_atr_pct=float(_e("MIN_ATR_PCT", 0.002)),
        trend_filter=_e("TREND_FILTER", "true").lower() in ("1", "true", "yes", "on"),
        train_candles=int(_e("TRAIN_CANDLES", 1000)),
        retrain_every=int(_e("RETRAIN_EVERY", 50)),
        horizon=int(_e("HORIZON", 3)),
        min_notional=float(_e("MIN_NOTIONAL", 10)),
        host=_e("HOST", "127.0.0.1"),
        port=int(_e("PORT", 8000)),
        state_dir=_e("STATE_DIR", str(Path(__file__).parent / "data")),
        auto_start=_e("AUTO_START_BOT", "false").lower() in ("1", "true", "yes", "on"),
    )
