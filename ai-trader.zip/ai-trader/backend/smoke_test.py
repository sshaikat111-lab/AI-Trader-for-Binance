"""Offline self-test: runs the whole bot on fake data. Run:  python smoke_test.py"""
import json
import os
import tempfile
import time

os.environ.update(TRADING_MODE="paper", DATA_SOURCE="synthetic", STATE_DIR=tempfile.mkdtemp())

from bot import TradingBot
from broker import PaperBroker
from config import load_config
from data import SyntheticData

cfg = load_config()
cfg.validate()
# loosen the filters so this test is guaranteed to place trades
cfg.min_val_accuracy, cfg.buy_threshold, cfg.min_atr_pct, cfg.trend_filter = 0.0, 0.5, 0.0, False

data = SyntheticData()
broker = PaperBroker(data, cfg.paper_start_balance, cfg.fee_rate, cfg.slippage)
bot = TradingBot(cfg, data, broker)

start_equity = bot.equity
bot._tick()
snap = bot.snapshot()
json.dumps(snap)  # must be JSON-serialisable

for s, sig in snap["signals"].items():
    m = sig["model"]
    print(f"{s}: P(up)={sig['prob_up']:.3f} action={sig['action']} val_acc={m['val_acc']:.3f} baseline={m['baseline']:.3f}")
assert snap["signals"], "no signals produced"

print("positions:", list(bot.positions))
assert bot.positions, "expected at least one position with loosened filters"
s, pos = next(iter(bot.positions.items()))
risk_pct = pos.risk_dist * pos.qty / start_equity
print(f"{s}: size {pos.qty * pos.entry_price:.2f} USDT, stop {pos.stop:.2f}, target {pos.take_profit:.2f}, "
      f"loss if stopped ~{risk_pct:.2%} of equity")
assert pos.stop < pos.entry_price < pos.take_profit
assert pos.qty * pos.entry_price <= start_equity * cfg.max_position_pct * 1.01

# 1) stop-loss triggers
bot.prices[s] = pos.stop * 0.999
bot._check_exits(time.time())
assert s not in bot.positions, "stop-loss did not close position"
last = bot.trades[-1]
print("stop-out:", last["reason"], f"pnl={last['pnl']:.2f}")
assert last["reason"] == "stop_loss" and last["pnl"] < 0

# 2) cash + equity accounting
bot._refresh_equity()
print(f"equity {start_equity:.2f} -> {bot.equity:.2f}")
assert abs((bot.equity - start_equity) - sum(t["pnl"] for t in bot.trades if t["side"] == "sell")
           - sum(p.qty * p.entry_price - p.quote_in for p in bot.positions.values())) < 5

# 3) daily loss limit halts trading and closes positions
bot.day_start_equity = bot.equity * 1.5
bot._check_daily_limit()
assert bot.halted and not bot.positions
print("daily limit:", bot.halt_reason)

# 4) state persists and reloads
bot2 = TradingBot(cfg, data, PaperBroker(data, cfg.paper_start_balance, cfg.fee_rate, cfg.slippage))
assert len(bot2.trades) == len(bot.trades)
print("persistence ok,", len(bot2.trades), "trades restored")
print("\nALL CHECKS PASSED")
