"""The trading loop: gets data, asks the AI model, applies risk rules, places orders."""
from __future__ import annotations

import json
import threading
import time
import uuid
from collections import deque
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path

from data import TF_SECONDS
from model import PriceModel


@dataclass
class Position:
    symbol: str
    qty: float
    entry_price: float
    quote_in: float        # USDT paid including fees
    stop: float
    take_profit: float
    risk_dist: float       # entry - initial stop
    opened_at: float
    trail_armed: bool = False


class TradingBot:
    def __init__(self, cfg, data, broker):
        self.cfg, self.data, self.broker = cfg, data, broker
        self.tf_s = TF_SECONDS[cfg.timeframe]
        self.lock = threading.RLock()
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None
        self.running = False

        self.positions: dict[str, Position] = {}
        self.trades: list[dict] = []
        self.logs: deque = deque(maxlen=300)
        self.signals: dict[str, dict] = {}
        self.equity_hist: deque = deque(maxlen=1500)
        self.prices: dict[str, float] = {}
        self.models = {s: PriceModel(cfg.horizon, cfg.min_val_accuracy, cfg.buy_threshold) for s in cfg.symbols}
        self.since_train = {s: 0 for s in cfg.symbols}
        self.processed_boundary: dict[str, int] = {}
        self.cooldown_until: dict[str, float] = {}

        self.equity = 0.0
        self.cash = 0.0
        self.initial_equity: float | None = None
        self.day: str | None = None
        self.day_start_equity: float | None = None
        self.halted = False
        self.halt_reason = ""

        self.state_file = Path(cfg.state_dir) / f"state_{cfg.mode}_{cfg.data_source}.json"
        self._load()
        self._refresh_equity()
        self.log("info", f"ready in {cfg.mode.upper()} mode, watching {', '.join(cfg.symbols)} on {cfg.timeframe} candles")

    # ------------------------------------------------------------------ utils
    def log(self, level: str, msg: str) -> None:
        self.logs.append({"t": time.time(), "level": level, "msg": msg})

    def _save(self) -> None:
        try:
            self.state_file.parent.mkdir(parents=True, exist_ok=True)
            payload = {
                "positions": {s: asdict(p) for s, p in self.positions.items()},
                "trades": self.trades[-500:],
                "initial_equity": self.initial_equity,
                "day": self.day,
                "day_start_equity": self.day_start_equity,
                "paper_cash": self.broker.cash if hasattr(self.broker, "cash") else None,
            }
            tmp = self.state_file.with_suffix(".tmp")
            tmp.write_text(json.dumps(payload))
            tmp.replace(self.state_file)
        except Exception as e:  # never crash the bot because of disk problems
            self.log("warn", f"could not save state: {e}")

    def _load(self) -> None:
        if not self.state_file.exists():
            return
        try:
            d = json.loads(self.state_file.read_text())
            self.positions = {s: Position(**p) for s, p in d.get("positions", {}).items()}
            self.trades = d.get("trades", [])
            self.initial_equity = d.get("initial_equity")
            self.day, self.day_start_equity = d.get("day"), d.get("day_start_equity")
            if d.get("paper_cash") is not None and hasattr(self.broker, "cash"):
                self.broker.cash = d["paper_cash"]
        except Exception as e:
            self.log("warn", f"could not read saved state, starting fresh: {e}")

    def _refresh_equity(self) -> None:
        self.cash = self.broker.quote_balance()
        value = sum(p.qty * self.prices.get(p.symbol, p.entry_price) for p in self.positions.values())
        self.equity = self.cash + value
        if self.initial_equity is None:
            self.initial_equity = self.equity
            self._save()
        today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
        if self.day != today:
            self.day, self.day_start_equity = today, self.equity
            if self.halted:
                self.halted, self.halt_reason = False, ""
                self.log("info", "new day: trading resumed")
            self._save()

    # -------------------------------------------------------------- lifecycle
    def start(self) -> None:
        with self.lock:
            if self.running:
                return
            self._stop.clear()
            self.running = True
            self._thread = threading.Thread(target=self._run, daemon=True, name="trading-loop")
            self._thread.start()
            self.log("info", "bot started")

    def stop(self) -> None:
        with self.lock:
            was = self.running
            self._stop.set()
            self.running = False
            if was:
                if self.positions:
                    self.log("warn", "bot stopped: open positions are NOT being watched (no stop-loss) until you start it again")
                else:
                    self.log("info", "bot stopped")

    def _run(self) -> None:
        while not self._stop.is_set():
            try:
                self._tick()
            except Exception as e:
                self.log("error", f"loop error: {e}")
            self._stop.wait(self.cfg.loop_seconds)
        if self._thread is threading.current_thread():
            self.running = False

    # ------------------------------------------------------------------- tick
    def _tick(self) -> None:
        now = time.time()
        for s in self.cfg.symbols:
            try:
                self.prices[s] = self.broker.price(s)
            except Exception as e:
                self.log("warn", f"price for {s} unavailable: {e}")

        with self.lock:
            self._refresh_equity()
            self._check_daily_limit()
            self._check_exits(now)
            if not self.equity_hist or now - self.equity_hist[-1][0] >= 20:
                self.equity_hist.append([now, self.equity])

        boundary = int(now // self.tf_s) * self.tf_s
        for s in self.cfg.symbols:
            if self._stop.is_set():
                break
            if self.processed_boundary.get(s) == boundary:
                continue
            try:
                self._process_symbol(s, boundary)
            except Exception as e:
                self.log("error", f"{s}: {e}")

    def _process_symbol(self, s: str, boundary: int) -> None:
        cfg = self.cfg
        df = self.data.ohlcv(s, cfg.timeframe, min(cfg.train_candles, 1000))
        df = df[df["ts"] < boundary * 1000].reset_index(drop=True)  # drop the unfinished candle
        if df.empty or int(df["ts"].iloc[-1]) != (boundary - self.tf_s) * 1000:
            return  # newest closed candle not published yet; retry next tick

        model = self.models[s]
        if model.model is None or self.since_train[s] >= cfg.retrain_every:
            st = model.fit(df)
            self.since_train[s] = 0
            verdict = "OK to trade" if model.ok else "too weak, trading disabled for this coin"
            self.log("info", f"{s}: model trained. Hit-rate on unseen data {st['val_acc']:.1%} "
                             f"(coin-flip baseline {st['baseline']:.1%}) - {verdict}")
        pred = model.predict(df)
        self.since_train[s] += 1
        self.processed_boundary[s] = boundary
        with self.lock:
            self._decide(s, pred, model)

    # --------------------------------------------------------------- decisions
    def _decide(self, s: str, pred: dict, model: PriceModel) -> None:
        cfg = self.cfg
        p = pred["prob_up"]
        pos = self.positions.get(s)
        action, reason = "WAIT", ""

        if pos:
            if p <= cfg.sell_threshold:
                try:
                    self._close(s, "ai_exit")
                    action, reason = "SELL", f"P(up) {p:.2f} fell to the exit level {cfg.sell_threshold:.2f}"
                except Exception as e:
                    reason = f"sell failed: {e}"
                    self.log("error", f"{s}: sell failed: {e}")
            else:
                action, reason = "HOLD", "position open, AI still not bearish"
        else:
            blockers = []
            if self.halted:
                blockers.append("trading halted for today")
            if not model.ok:
                blockers.append(f"model too weak ({model.stats['val_acc']:.1%} on unseen data)")
            if p < cfg.buy_threshold:
                blockers.append(f"P(up) {p:.2f} is below the buy level {cfg.buy_threshold:.2f}")
            if pred["atr_pct"] < cfg.min_atr_pct:
                blockers.append("price moves too small to beat fees")
            if cfg.trend_filter and not pred["trend_ok"]:
                blockers.append("price is below its trend average")
            if len(self.positions) >= cfg.max_open_positions:
                blockers.append("max open positions reached")
            if time.time() < self.cooldown_until.get(s, 0):
                blockers.append("cooling down after last trade")
            if blockers:
                reason = "; ".join(blockers)
            else:
                ok, msg = self._open(s, pred)
                action, reason = ("BUY", f"P(up) {p:.2f} passed all checks") if ok else ("WAIT", msg)

        self.signals[s] = {
            "symbol": s, "time": time.time(), "prob_up": p, "action": action, "reason": reason,
            "price": self.prices.get(s, pred["close"]), "rsi": pred["rsi"], "atr_pct": pred["atr_pct"],
            "trend_ok": pred["trend_ok"], "model": {**model.stats, "ok": model.ok},
        }

    def _open(self, s: str, pred: dict):
        cfg = self.cfg
        price = self.prices.get(s, pred["close"])
        stop_dist = cfg.atr_stop_mult * pred["atr"]
        if stop_dist <= 0 or stop_dist >= price * 0.3:
            return False, "could not size the stop-loss"
        cash = self.broker.quote_balance()
        notional = self.equity * cfg.risk_per_trade / stop_dist * price   # size so a stop-out loses ~risk_per_trade
        notional = min(notional, self.equity * cfg.max_position_pct, cash * 0.98)
        if notional < cfg.min_notional:
            return False, f"trade size {notional:.2f} USDT is below the minimum"
        try:
            fill = self.broker.buy(s, notional)
        except Exception as e:
            self.cooldown_until[s] = time.time() + self.tf_s
            self.log("error", f"{s}: buy failed: {e}")
            return False, f"buy failed: {e}"
        self.positions[s] = Position(
            symbol=s, qty=fill.qty, entry_price=fill.price, quote_in=fill.quote,
            stop=fill.price - stop_dist, take_profit=fill.price + cfg.take_profit_rr * stop_dist,
            risk_dist=stop_dist, opened_at=time.time(),
        )
        self._record("buy", s, fill, None, None, "ai_signal")
        self.log("trade", f"BOUGHT {fill.qty:.6g} {s.split('/')[0]} at {fill.price:,.2f} "
                          f"(stop {self.positions[s].stop:,.2f}, target {self.positions[s].take_profit:,.2f})")
        self._save()
        return True, ""

    def _close(self, s: str, reason: str) -> None:
        pos = self.positions.get(s)
        if not pos:
            return
        fill = self.broker.sell(s, pos.qty)          # raises if it fails; position stays open
        pnl = fill.quote - pos.quote_in
        pnl_pct = pnl / pos.quote_in * 100 if pos.quote_in else 0.0
        del self.positions[s]
        self.cooldown_until[s] = time.time() + self.cfg.cooldown_candles * self.tf_s
        self._record("sell", s, fill, pnl, pnl_pct, reason)
        self.log("trade", f"SOLD {s} at {fill.price:,.2f} ({reason}), P&L {pnl:+.2f} USDT ({pnl_pct:+.2f}%)")
        self._save()

    def _record(self, side, s, fill, pnl, pnl_pct, reason) -> None:
        self.trades.append({
            "id": uuid.uuid4().hex[:8], "time": time.time(), "symbol": s, "side": side,
            "qty": fill.qty, "price": fill.price, "quote": fill.quote,
            "pnl": pnl, "pnl_pct": pnl_pct, "reason": reason, "mode": self.cfg.mode,
        })
        self.trades = self.trades[-500:]

    def _check_exits(self, now: float) -> None:
        cfg = self.cfg
        for s, pos in list(self.positions.items()):
            price = self.prices.get(s)
            if price is None:
                continue
            if not pos.trail_armed and price >= pos.entry_price + pos.risk_dist:
                pos.stop = max(pos.stop, pos.entry_price * (1 + 2 * cfg.fee_rate))
                pos.trail_armed = True
                self.log("info", f"{s}: up 1x risk, stop-loss moved to break-even")
            reason = None
            if price <= pos.stop:
                reason = "breakeven_stop" if pos.trail_armed else "stop_loss"
            elif price >= pos.take_profit:
                reason = "take_profit"
            elif now - pos.opened_at >= cfg.max_hold_candles * self.tf_s:
                reason = "time_exit"
            if reason:
                try:
                    self._close(s, reason)
                except Exception as e:
                    self.log("error", f"{s}: could not close ({reason}): {e}")

    def _check_daily_limit(self) -> None:
        if self.halted or not self.day_start_equity:
            return
        if self.equity <= self.day_start_equity * (1 - self.cfg.daily_loss_limit):
            self.halted = True
            self.halt_reason = f"Daily loss limit of {self.cfg.daily_loss_limit:.0%} reached. No new trades until tomorrow (UTC)."
            self.log("error", self.halt_reason)
            for s in list(self.positions):
                try:
                    self._close(s, "daily_loss_limit")
                except Exception as e:
                    self.log("error", f"{s}: could not close: {e}")

    # ------------------------------------------------------------ manual actions
    def close_position(self, symbol: str) -> None:
        with self.lock:
            if symbol not in self.positions:
                raise KeyError(f"no open position for {symbol}")
            self.prices.setdefault(symbol, self.broker.price(symbol))
            self._close(symbol, "manual")
            self._refresh_equity()

    def panic(self) -> None:
        """Stop the bot and sell everything."""
        self.stop()
        with self.lock:
            errors = []
            for s in list(self.positions):
                try:
                    self._close(s, "panic")
                except Exception as e:
                    errors.append(f"{s}: {e}")
            self._refresh_equity()
            if errors:
                raise RuntimeError("Could not close: " + "; ".join(errors))

    def reset_paper(self) -> None:
        if self.cfg.mode != "paper":
            raise RuntimeError("reset is only available in paper mode")
        if self.running:
            raise RuntimeError("stop the bot first")
        with self.lock:
            self.broker.cash = self.broker.start_balance
            self.positions.clear()
            self.trades.clear()
            self.signals.clear()
            self.equity_hist.clear()
            self.initial_equity = None
            self.day = None
            self.halted, self.halt_reason = False, ""
            self._refresh_equity()
            self._save()
            self.log("info", "paper account reset")

    # ---------------------------------------------------------------- snapshot
    def snapshot(self) -> dict:
        cfg = self.cfg
        with self.lock:
            positions = []
            for s, p in self.positions.items():
                px = self.prices.get(s, p.entry_price)
                value = p.qty * px
                pnl = value * (1 - cfg.fee_rate) - p.quote_in
                positions.append({**asdict(p), "price": px, "value": value, "pnl": pnl,
                                  "pnl_pct": pnl / p.quote_in * 100 if p.quote_in else 0})
            closed = [t for t in self.trades if t["side"] == "sell"]
            wins = [t for t in closed if t["pnl"] > 0]
            gross_win = sum(t["pnl"] for t in wins)
            gross_loss = -sum(t["pnl"] for t in closed if t["pnl"] <= 0)
            init = self.initial_equity or self.equity
            dstart = self.day_start_equity or self.equity
            return {
                "mode": cfg.mode, "data_source": cfg.data_source, "running": self.running,
                "halted": self.halted, "halt_reason": self.halt_reason,
                "symbols": cfg.symbols, "timeframe": cfg.timeframe, "server_time": time.time(),
                "equity": self.equity, "cash": self.cash, "initial_equity": init,
                "pnl": self.equity - init, "pnl_pct": (self.equity / init - 1) * 100 if init else 0,
                "day_pnl": self.equity - dstart, "day_pnl_pct": (self.equity / dstart - 1) * 100 if dstart else 0,
                "stats": {
                    "trades": len(closed),
                    "win_rate": len(wins) / len(closed) if closed else None,
                    "realized_pnl": sum(t["pnl"] for t in closed),
                    "profit_factor": gross_win / gross_loss if gross_loss > 0 else None,
                },
                "positions": positions,
                "trades": list(reversed(self.trades[-100:])),
                "signals": self.signals,
                "equity_history": list(self.equity_hist),
                "logs": list(reversed(list(self.logs)[-80:])),
                "config": cfg.public(),
            }
