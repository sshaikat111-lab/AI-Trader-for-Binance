"""Order execution: PaperBroker (simulated) and CCXTBroker (Binance live / testnet)."""
from __future__ import annotations

import functools
import threading
from dataclasses import dataclass


def _locked(fn):
    """Serialise calls on the shared exchange object (two bot threads use it)."""
    @functools.wraps(fn)
    def wrapper(self, *a, **k):
        with self._io:
            return fn(self, *a, **k)
    return wrapper


@dataclass
class Fill:
    qty: float    # base coin amount (net of fees taken in that coin)
    price: float  # average fill price
    quote: float  # USDT spent (buy) or received (sell), fees included


class PaperBroker:
    """Simulated account. Uses real prices but fake money."""

    name = "paper"

    def __init__(self, data, start_balance: float, fee_rate: float, slippage: float):
        self.data, self.cash = data, start_balance
        self.start_balance, self.fee_rate, self.slippage = start_balance, fee_rate, slippage

    def price(self, symbol: str) -> float:
        return self.data.price(symbol)

    def quote_balance(self) -> float:
        return self.cash

    def buy(self, symbol: str, quote_amount: float) -> Fill:
        if quote_amount > self.cash + 1e-9:
            raise ValueError("not enough paper balance")
        px = self.price(symbol) * (1 + self.slippage)
        qty = quote_amount * (1 - self.fee_rate) / px
        self.cash -= quote_amount
        return Fill(qty, px, quote_amount)

    def sell(self, symbol: str, qty: float) -> Fill:
        px = self.price(symbol) * (1 - self.slippage)
        quote = qty * px * (1 - self.fee_rate)
        self.cash += quote
        return Fill(qty, px, quote)


class CCXTBroker:
    """Real Binance spot account (mode 'live') or Binance's test exchange (mode 'testnet')."""

    def __init__(self, mode: str, api_key: str, api_secret: str):
        import ccxt

        self.name = mode
        self._io = threading.RLock()   # the monitor and analysis threads share one exchange object
        self.ex = ccxt.binance({
            "apiKey": api_key,
            "secret": api_secret,
            "enableRateLimit": True,
            "options": {"defaultType": "spot", "adjustForTimeDifference": True},
        })
        if mode == "testnet":
            self.ex.set_sandbox_mode(True)
        self.ex.load_markets()

    @_locked
    def price(self, symbol: str) -> float:
        return float(self.ex.fetch_ticker(symbol)["last"])

    @_locked
    def quote_balance(self) -> float:
        return float(self.ex.fetch_balance()["USDT"]["free"])

    def _fill_from_order(self, order: dict, symbol: str, side: str) -> Fill:
        if not order.get("average") or order.get("filled") is None:
            order = self.ex.fetch_order(order["id"], symbol)
        base, quote = symbol.split("/")
        filled = float(order["filled"])
        avg = float(order.get("average") or order.get("price"))
        cost = float(order.get("cost") or filled * avg)
        fees = order.get("fees") or ([order["fee"]] if order.get("fee") else [])
        qty, quote_amt = filled, cost
        for f in fees:
            amt = float(f.get("cost") or 0)
            if f.get("currency") == base and side == "buy":
                qty -= amt                     # Binance takes the fee out of the coin you bought
            elif f.get("currency") == quote:
                quote_amt += amt if side == "buy" else -amt
            # fees paid in BNB are not converted here (small error in P&L)
        return Fill(qty, avg, quote_amt)

    @_locked
    def buy(self, symbol: str, quote_amount: float) -> Fill:
        m = self.ex.market(symbol)
        px = self.price(symbol)
        amount = float(self.ex.amount_to_precision(symbol, quote_amount / px))
        min_cost = (m.get("limits", {}).get("cost", {}) or {}).get("min") or 0
        if amount * px < min_cost:
            raise ValueError(f"order value {amount * px:.2f} is below Binance minimum {min_cost}")
        return self._fill_from_order(self.ex.create_market_buy_order(symbol, amount), symbol, "buy")

    @_locked
    def sell(self, symbol: str, qty: float) -> Fill:
        base = symbol.split("/")[0]
        free = float(self.ex.fetch_balance()[base]["free"])
        amount = float(self.ex.amount_to_precision(symbol, min(qty, free)))
        if amount <= 0:
            raise ValueError(f"no {base} available to sell")
        return self._fill_from_order(self.ex.create_market_sell_order(symbol, amount), symbol, "sell")


def make_broker(cfg, data, mode: str | None = None):
    mode = mode or cfg.mode
    if mode == "paper":
        return PaperBroker(data, cfg.paper_start_balance, cfg.fee_rate, cfg.slippage)
    return CCXTBroker(mode, cfg.api_key, cfg.api_secret)
