"""The trading loop: gets data, asks the AI (statistical model and/or Gemini), applies risk rules, places orders."""
from __future__ import annotations

import json
import threading
import time
import uuid
from collections import deque
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path

from data import TF_SECONDS
from gemini import GeminiError
from model import PriceModel

STRATEGIES = ("ml", "gemini", "hybrid")
SIGNAL_REASON = {"ml": "ai_signal", "gemini": "gemini_signal", "hybrid": "hybrid_signal"}


@dataclass
class Position:
    symbol: str
    qty: float
    entry_price: float
    quote_in: float        # USDT paid including fees
    stop: float
    take_profit: float
    risk_dist: float       # entry - initial stop
    opened_at: float
    trail_armed: bool = False


class TradingBot:
    def __init__(self, cfg, data, broker, analyst=None):
        self.cfg, self.data, self.broker, self.analyst = cfg, data, broker, analyst
        self.tf_s = TF_SECONDS[cfg.timeframe]
        self.lock = threading.RLock()
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None            # monitor: prices, stops, daily limit
        self._analysis_thread: threading.Thread | None = None   # analysis: candles, model, Gemini
        self.running = False

        self.positions: dict[str, Position] = {}
        self.trades: list[dict] = []
        self.logs: deque = deque(maxlen=300)
        self.signals: dict[str, dict] = {}
        self.gemini_last: dict[str, dict] = {}
        self.equity_hist: deque = deque(maxlen=1500)
        self.prices: dict[str, float] = {}
        self.models = {s: PriceModel(cfg.horizon, cfg.min_val_accuracy, cfg.buy_threshold) for s in cfg.symbols}
        self.since_train = {s: 0 for s in cfg.symbols}
        self.processed_boundary: dict[str, int] = {}
        self.cooldown_until: dict[str, float] = {}

        self.equity = 0.0
        self.cash = 0.0
        self.initial_equity: float | None = None
        self.day: str | None = None
        self.day_start_equity: float | None = None
        self.halted = False
        self.halt_reason = ""

        self.strategy = cfg.strategy
        if self.strategy in ("gemini", "hybrid") and not self.gemini_enabled:
            self.log("warn", f"STRATEGY={self.strategy} needs GEMINI_API_KEY. Using the statistical model only.")
            self.strategy = "ml"

        self.state_file = self._state_path()
        self._load()
        self._refresh_equity()
        self.log("info", f"ready in {cfg.mode.upper()} mode, AI engine: {self.strategy}, "
                         f"watching {', '.join(cfg.symbols)} on {cfg.timeframe} candles")

    # ------------------------------------------------------------------ utils
    @property
    def gemini_enabled(self) -> bool:
        return bool(self.analyst and self.analyst.enabled)

    def log(self, level: str, msg: str) -> None:
        self.logs.append({"t": time.time(), "level": level, "msg": msg})

    def _state_path(self) -> Path:
        return Path(self.cfg.state_dir) / f"state_{self.cfg.mode}_{self.cfg.data_source}.json"

    def _save(self) -> None:
        try:
            self.state_file.parent.mkdir(parents=True, exist_ok=True)
            payload = {
                "positions": {s: asdict(p) for s, p in self.positions.items()},
                "trades": self.trades[-500:],
                "initial_equity": self.initial_equity,
                "day": self.day,
                "day_start_equity": self.day_start_equity,
                "paper_cash": self.broker.cash if hasattr(self.broker, "cash") else None,
            }
            tmp = self.state_file.with_suffix(".tmp")
            tmp.write_text(json.dumps(payload))
            tmp.replace(self.state_file)
        except Exception as e:  # never crash the bot because of disk problems
            self.log("warn", f"could not save state: {e}")

    def _load(self) -> None:
        if not self.state_file.exists():
            return
        try:
            d = json.loads(self.state_file.read_text())
            self.positions = {s: Position(**p) for s, p in d.get("positions", {}).items()}
            self.trades = d.get("trades", [])
            self.initial_equity = d.get("initial_equity")
            self.day, self.day_start_equity = d.get("day"), d.get("day_start_equity")
            if d.get("paper_cash") is not None and hasattr(self.broker, "cash"):
                self.broker.cash = d["paper_cash"]
        except Exception as e:
            self.log("warn", f"could not read saved state, starting fresh: {e}")

    def _refresh_equity(self) -> None:
        self.cash = self.broker.quote_balance()
        value = sum(p.qty * self.prices.get(p.symbol, p.entry_price) for p in self.positions.values())
        self.equity = self.cash + value
        if self.initial_equity is None:
            self.initial_equity = self.equity
            self._save()
        today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
        if self.day != today:
            self.day, self.day_start_equity = today, self.equity
            if self.halted:
                self.halted, self.halt_reason = False, ""
                self.log("info", "new day: trading resumed")
            self._save()

    # -------------------------------------------------------------- lifecycle
    def start(self) -> None:
        with self.lock:
            if self.running:
                return
            if any(t and t.is_alive() for t in (self._thread, self._analysis_thread)):
                raise RuntimeError("The bot is still finishing its previous step. Try again in a few seconds.")
            self._stop.clear()
            self.running = True
            # Two threads so that a slow Gemini call can never delay stop-loss and take-profit checks.
            self._thread = threading.Thread(target=self._monitor_loop, daemon=True, name="monitor")
            self._analysis_thread = threading.Thread(target=self._analysis_loop, daemon=True, name="analysis")
            self._thread.start()
            self._analysis_thread.start()
            self.log("info", "bot started")

    def stop(self) -> None:
        with self.lock:
            was = self.running
            self._stop.set()
            self.running = False
            if was:
                if self.positions:
                    self.log("warn", "bot stopped: open positions are NOT being watched (no stop-loss) until you start it again")
                else:
                    self.log("info", "bot stopped")

    def _monitor_loop(self) -> None:
        while not self._stop.is_set():
            try:
                self._monitor_step()
            except Exception as e:
                self.log("error", f"monitor error: {e}")
            self._stop.wait(self.cfg.loop_seconds)

    def _analysis_loop(self) -> None:
        while not self._stop.is_set():
            try:
                self._analysis_step()
            except Exception as e:
                self.log("error", f"analysis error: {e}")
            self._stop.wait(self.cfg.loop_seconds)

    # -------------------------------------------------- mode and engine switching
    def switch_blocker(self) -> str:
        if self.running:
            return "Stop the bot before changing mode."
        if self.positions:
            return "Sell all open positions before changing mode."
        return ""

    def apply_mode(self, mode: str, broker) -> None:
        """Swap to another account type. Each mode keeps its own saved records."""
        with self.lock:
            reason = self.switch_blocker()
            if reason:
                raise RuntimeError(reason)
            self.cfg.mode, self.broker = mode, broker
            self.state_file = self._state_path()
            self.positions, self.trades = {}, []
            self.signals.clear()
            self.equity_hist.clear()
            self.prices.clear()
            self.cooldown_until.clear()
            self.processed_boundary.clear()
            self.initial_equity = self.day = self.day_start_equity = None
            self.halted, self.halt_reason = False, ""
            self._load()
            self._refresh_equity()
            self.log("info", f"switched to {mode.upper()} mode")

    def set_strategy(self, strategy: str) -> None:
        if strategy not in STRATEGIES:
            raise ValueError("unknown AI engine")
        if strategy in ("gemini", "hybrid") and not self.gemini_enabled:
            raise ValueError("Add GEMINI_API_KEY to backend/.env and restart to use Gemini.")
        with self.lock:
            if strategy != self.strategy:
                self.strategy = strategy
                self.log("info", f"AI engine changed to: {strategy}. Takes effect from the next candle.")

    # ------------------------------------------------------------------- steps
    def _tick(self) -> None:
        """One monitor step followed by one analysis step (used by the tests)."""
        self._monitor_step()
        self._analysis_step()

    def _monitor_step(self) -> None:
        """Fast and network-light: prices, account value, daily loss limit, stop-loss / take-profit."""
        now = time.time()
        for s in self.cfg.symbols:
            try:
                self.prices[s] = self.broker.price(s)
            except Exception as e:
                self.log("warn", f"price for {s} unavailable: {e}")
        with self.lock:
            self._refresh_equity()
            self._check_daily_limit()
            self._check_exits(now)
            if not self.equity_hist or now - self.equity_hist[-1][0] >= 20:
                self.equity_hist.append([now, self.equity])

    def _analysis_step(self) -> None:
        """Slow work, once per new candle: download candles, (re)train, ask Gemini, decide."""
        boundary = int(time.time() // self.tf_s) * self.tf_s
        for s in self.cfg.symbols:
            if self._stop.is_set():
                break
            if self.processed_boundary.get(s) == boundary:
                continue
            try:
                self._process_symbol(s, boundary)
            except Exception as e:
                self.log("error", f"{s}: {e}")

    def _process_symbol(self, s: str, boundary: int) -> None:
        cfg = self.cfg
        df = self.data.ohlcv(s, cfg.timeframe, min(cfg.train_candles, 1000))
        df = df[df["ts"] < boundary * 1000].reset_index(drop=True)  # drop the unfinished candle
        if df.empty or int(df["ts"].iloc[-1]) != (boundary - self.tf_s) * 1000:
            return  # newest closed candle not published yet; retry next tick

        model = self.models[s]
        if model.model is None or self.since_train[s] >= cfg.retrain_every:
            st = model.fit(df)
            self.since_train[s] = 0
            verdict = "OK to trade" if model.ok else "too weak for the statistical model to trade on its own"
            self.log("info", f"{s}: model trained. Hit-rate on unseen data {st['val_acc']:.1%} "
                             f"(coin-flip baseline {st['baseline']:.1%}) - {verdict}")
        pred = model.predict(df)
        self.since_train[s] += 1

        g = None
        if self.strategy in ("gemini", "hybrid"):
            with self.lock:
                need = self._needs_gemini(s, pred, model)
            if need:
                g = self._analyze_gemini(s, df, pred, model)   # network call: done outside the lock
        with self.lock:
            if self._stop.is_set():
                return      # Stop was pressed while we were analysing: place nothing, re-check this candle on restart
            self.processed_boundary[s] = boundary
            self._decide(s, pred, model, g)

    # ------------------------------------------------------------------ Gemini
    def _needs_gemini(self, s: str, pred: dict, model: PriceModel) -> bool:
        """Only spend a Gemini call when its answer could change what the bot does."""
        if s in self.positions:
            return True
        blockers = self._base_blockers(s, pred)
        if self.strategy == "hybrid":
            blockers += self._ml_blockers(pred, model)
        return not blockers

    def _analyze_gemini(self, s: str, df, pred: dict, model: PriceModel) -> dict:
        cfg = self.cfg
        with self.lock:
            pos = self.positions.get(s)
            pos_info = None
            if pos:
                px = self.prices.get(s, pred["close"])
                pos_info = {"entry": pos.entry_price, "stop": pos.stop, "target": pos.take_profit,
                            "pnl_pct": (px / pos.entry_price - 1) * 100}
        st = model.stats or {}
        payload = {
            "symbol": s, "timeframe": cfg.timeframe, "price": self.prices.get(s, pred["close"]),
            "round_trip_cost_pct": (2 * cfg.fee_rate + 2 * cfg.slippage) * 100,
            "indicators": {k: pred[k] for k in ("rsi", "ema_ratio", "macd_h", "bb_pos", "atr_pct", "vol_z", "trend_dist")},
            "ml": {"prob_up": pred["prob_up"], "horizon": cfg.horizon, "val_acc": st.get("val_acc", 0.5),
                   "baseline": st.get("baseline", 0.5), "reliable": model.ok},
            "position": pos_info,
            "candles": df.tail(48)[["ts", "open", "high", "low", "close", "volume"]].values.tolist(),
        }
        try:
            res = self.analyst.analyze(payload)
            res["ok"] = True
            self.log("info", f"Gemini on {s}: {res['action']} ({res['confidence']:.0%}), "
                             f"trend {res['trend'].lower()}. {res['reasoning']}")
        except GeminiError as e:
            res = {"ok": False, "error": str(e)}
            self.log("warn", f"Gemini on {s} unavailable: {e}")
        except Exception as e:
            res = {"ok": False, "error": f"unexpected error: {e}"}
            self.log("warn", f"Gemini on {s} failed: {e}")
        res["time"] = time.time()
        self.gemini_last[s] = res
        return res

    # --------------------------------------------------------------- decisions
    def _base_blockers(self, s: str, pred: dict) -> list:
        cfg = self.cfg
        b = []
        if self.halted:
            b.append("trading halted for today")
        if pred["atr_pct"] < cfg.min_atr_pct:
            b.append("price moves too small to beat fees")
        if cfg.trend_filter and not pred["trend_ok"]:
            b.append("price is below its trend average")
        if len(self.positions) >= cfg.max_open_positions:
            b.append("max open positions reached")
        if time.time() < self.cooldown_until.get(s, 0):
            b.append("cooling down after last trade")
        return b

    def _ml_blockers(self, pred: dict, model: PriceModel) -> list:
        cfg = self.cfg
        b = []
        if not model.ok:
            b.append(f"model too weak ({model.stats['val_acc']:.1%} on unseen data)")
        if pred["prob_up"] < cfg.buy_threshold:
            b.append(f"P(up) {pred['prob_up']:.2f} is below the buy level {cfg.buy_threshold:.2f}")
        return b

    def _decide(self, s: str, pred: dict, model: PriceModel, g: dict | None) -> None:
        cfg, st = self.cfg, self.strategy
        p = pred["prob_up"]
        pos = self.positions.get(s)
        gok = bool(g and g.get("ok"))
        need = cfg.gemini_min_confidence
        g_buy = gok and g["action"] == "BUY" and g["confidence"] >= need
        g_sell = gok and g["action"] == "SELL" and g["confidence"] >= need
        action, reason = "WAIT", ""

        if pos:
            ml_exit = p <= cfg.sell_threshold
            why = None
            if st in ("gemini", "hybrid") and g_sell:
                why = ("gemini_exit", f"Gemini advises selling ({g['confidence']:.0%} confident)")
            elif st in ("ml", "hybrid") and ml_exit:
                why = ("ai_exit", f"P(up) {p:.2f} fell to the exit level {cfg.sell_threshold:.2f}")
            if why:
                try:
                    self._close(s, why[0])
                    action, reason = "SELL", why[1]
                except Exception as e:
                    reason = f"sell failed: {e}"
                    self.log("error", f"{s}: sell failed: {e}")
            else:
                action, reason = "HOLD", "position open, no exit signal"
        else:
            blockers = self._base_blockers(s, pred)
            if st in ("ml", "hybrid"):
                blockers += self._ml_blockers(pred, model)
            if not blockers and st in ("gemini", "hybrid"):
                if g is None:
                    blockers.append("Gemini did not answer")
                elif not gok:
                    blockers.append(f"Gemini unavailable ({g.get('error', 'unknown error')})")
                elif not g_buy:
                    if g["action"] == "BUY":
                        blockers.append(f"Gemini says BUY but only {g['confidence']:.0%} confident (needs {need:.0%})")
                    else:
                        blockers.append(f"Gemini says {g['action']} ({g['confidence']:.0%})")
            if blockers:
                reason = "; ".join(blockers)
            else:
                ok, msg = self._open(s, pred, SIGNAL_REASON[st])
                if ok:
                    action = "BUY"
                    reason = {"ml": f"P(up) {p:.2f} passed all checks",
                              "gemini": f"Gemini BUY ({g['confidence']:.0%}) and all checks passed" if g else "",
                              "hybrid": f"model P(up) {p:.2f} and Gemini agree, all checks passed"}[st]
                else:
                    reason = msg

        self.signals[s] = {
            "symbol": s, "time": time.time(), "prob_up": p, "action": action, "reason": reason,
            "price": self.prices.get(s, pred["close"]), "rsi": pred["rsi"], "atr_pct": pred["atr_pct"],
            "trend_ok": pred["trend_ok"], "strategy": st, "model": {**model.stats, "ok": model.ok},
            "gemini": self.gemini_last.get(s),
        }

    def _open(self, s: str, pred: dict, reason_code: str):
        cfg = self.cfg
        price = self.prices.get(s, pred["close"])
        stop_dist = cfg.atr_stop_mult * pred["atr"]
        if stop_dist <= 0 or stop_dist >= price * 0.3:
            return False, "could not size the stop-loss"
        cash = self.broker.quote_balance()
        notional = self.equity * cfg.risk_per_trade / stop_dist * price   # size so a stop-out loses ~risk_per_trade
        notional = min(notional, self.equity * cfg.max_position_pct, cash * 0.98)
        if notional < cfg.min_notional:
            return False, f"trade size {notional:.2f} USDT is below the minimum"
        try:
            fill = self.broker.buy(s, notional)
        except Exception as e:
            self.cooldown_until[s] = time.time() + self.tf_s
            self.log("error", f"{s}: buy failed: {e}")
            return False, f"buy failed: {e}"
        self.positions[s] = Position(
            symbol=s, qty=fill.qty, entry_price=fill.price, quote_in=fill.quote,
            stop=fill.price - stop_dist, take_profit=fill.price + cfg.take_profit_rr * stop_dist,
            risk_dist=stop_dist, opened_at=time.time(),
        )
        self._record("buy", s, fill, None, None, reason_code)
        self.log("trade", f"BOUGHT {fill.qty:.6g} {s.split('/')[0]} at {fill.price:,.2f} "
                          f"(stop {self.positions[s].stop:,.2f}, target {self.positions[s].take_profit:,.2f})")
        self._save()
        return True, ""

    def _close(self, s: str, reason: str) -> None:
        pos = self.positions.get(s)
        if not pos:
            return
        fill = self.broker.sell(s, pos.qty)          # raises if it fails; position stays open
        pnl = fill.quote - pos.quote_in
        pnl_pct = pnl / pos.quote_in * 100 if pos.quote_in else 0.0
        del self.positions[s]
        self.cooldown_until[s] = time.time() + self.cfg.cooldown_candles * self.tf_s
        self._record("sell", s, fill, pnl, pnl_pct, reason)
        self.log("trade", f"SOLD {s} at {fill.price:,.2f} ({reason}), P&L {pnl:+.2f} USDT ({pnl_pct:+.2f}%)")
        self._save()

    def _record(self, side, s, fill, pnl, pnl_pct, reason) -> None:
        self.trades.append({
            "id": uuid.uuid4().hex[:8], "time": time.time(), "symbol": s, "side": side,
            "qty": fill.qty, "price": fill.price, "quote": fill.quote,
            "pnl": pnl, "pnl_pct": pnl_pct, "reason": reason, "mode": self.cfg.mode,
        })
        self.trades = self.trades[-500:]

    def _check_exits(self, now: float) -> None:
        cfg = self.cfg
        for s, pos in list(self.positions.items()):
            price = self.prices.get(s)
            if price is None:
                continue
            if not pos.trail_armed and price >= pos.entry_price + pos.risk_dist:
                pos.stop = max(pos.stop, pos.entry_price * (1 + 2 * cfg.fee_rate))
                pos.trail_armed = True
                self.log("info", f"{s}: up 1x risk, stop-loss moved to break-even")
            reason = None
            if price <= pos.stop:
                reason = "breakeven_stop" if pos.trail_armed else "stop_loss"
            elif price >= pos.take_profit:
                reason = "take_profit"
            elif now - pos.opened_at >= cfg.max_hold_candles * self.tf_s:
                reason = "time_exit"
            if reason:
                try:
                    self._close(s, reason)
                except Exception as e:
                    self.log("error", f"{s}: could not close ({reason}): {e}")

    def _check_daily_limit(self) -> None:
        if self.halted or not self.day_start_equity:
            return
        if self.equity <= self.day_start_equity * (1 - self.cfg.daily_loss_limit):
            self.halted = True
            self.halt_reason = f"Daily loss limit of {self.cfg.daily_loss_limit:.0%} reached. No new trades until tomorrow (UTC)."
            self.log("error", self.halt_reason)
            for s in list(self.positions):
                try:
                    self._close(s, "daily_loss_limit")
                except Exception as e:
                    self.log("error", f"{s}: could not close: {e}")

    # ------------------------------------------------------------ manual actions
    def close_position(self, symbol: str) -> None:
        with self.lock:
            if symbol not in self.positions:
                raise KeyError(f"no open position for {symbol}")
            self.prices.setdefault(symbol, self.broker.price(symbol))
            self._close(symbol, "manual")
            self._refresh_equity()

    def panic(self) -> None:
        """Stop the bot and sell everything."""
        self.stop()
        with self.lock:
            errors = []
            for s in list(self.positions):
                try:
                    self._close(s, "panic")
                except Exception as e:
                    errors.append(f"{s}: {e}")
            self._refresh_equity()
            if errors:
                raise RuntimeError("Could not close: " + "; ".join(errors))

    def reset_paper(self) -> None:
        if self.cfg.mode != "paper":
            raise RuntimeError("reset is only available in paper mode")
        if self.running:
            raise RuntimeError("stop the bot first")
        with self.lock:
            self.broker.cash = self.broker.start_balance
            self.positions.clear()
            self.trades.clear()
            self.signals.clear()
            self.equity_hist.clear()
            self.initial_equity = None
            self.day = None
            self.halted, self.halt_reason = False, ""
            self._refresh_equity()
            self._save()
            self.log("info", "paper account reset")

    # ---------------------------------------------------------------- snapshot
    def _mode_options(self) -> dict:
        cfg = self.cfg
        has_keys = bool(cfg.api_key and cfg.api_secret)
        opts = {"paper": {"available": True, "reason": ""}}
        for m in ("testnet", "live"):
            if cfg.data_source != "binance":
                opts[m] = {"available": False, "reason": "Demo data is on (DATA_SOURCE=synthetic). Real accounts need real Binance data."}
            elif not has_keys:
                opts[m] = {"available": False, "reason": "Add BINANCE_API_KEY and BINANCE_API_SECRET to backend/.env, then restart the program."}
            else:
                opts[m] = {"available": True, "reason": ""}
        return opts

    def snapshot(self) -> dict:
        cfg = self.cfg
        with self.lock:
            positions = []
            for s, p in self.positions.items():
                px = self.prices.get(s, p.entry_price)
                value = p.qty * px
                pnl = value * (1 - cfg.fee_rate) - p.quote_in
                positions.append({**asdict(p), "price": px, "value": value, "pnl": pnl,
                                  "pnl_pct": pnl / p.quote_in * 100 if p.quote_in else 0})
            closed = [t for t in self.trades if t["side"] == "sell"]
            wins = [t for t in closed if t["pnl"] > 0]
            gross_win = sum(t["pnl"] for t in wins)
            gross_loss = -sum(t["pnl"] for t in closed if t["pnl"] <= 0)
            init = self.initial_equity or self.equity
            dstart = self.day_start_equity or self.equity
            return {
                "mode": cfg.mode, "data_source": cfg.data_source, "running": self.running,
                "halted": self.halted, "halt_reason": self.halt_reason,
                "symbols": cfg.symbols, "timeframe": cfg.timeframe, "server_time": time.time(),
                "strategy": self.strategy,
                "gemini": self.analyst.usage() if self.analyst else {"enabled": False},
                "modes": self._mode_options(), "switch_blocked": self.switch_blocker(),
                "equity": self.equity, "cash": self.cash, "initial_equity": init,
                "pnl": self.equity - init, "pnl_pct": (self.equity / init - 1) * 100 if init else 0,
                "day_pnl": self.equity - dstart, "day_pnl_pct": (self.equity / dstart - 1) * 100 if dstart else 0,
                "stats": {
                    "trades": len(closed),
                    "win_rate": len(wins) / len(closed) if closed else None,
                    "realized_pnl": sum(t["pnl"] for t in closed),
                    "profit_factor": gross_win / gross_loss if gross_loss > 0 else None,
                },
                "positions": positions,
                "trades": list(reversed(self.trades[-100:])),
                "signals": self.signals,
                "equity_history": list(self.equity_hist),
                "logs": list(reversed(list(self.logs)[-80:])),
                "config": cfg.public(),
            }
