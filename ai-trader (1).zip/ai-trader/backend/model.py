"""The 'AI': a small gradient-boosting model that estimates P(price is higher in N candles)."""
from __future__ import annotations

import time

import numpy as np
import pandas as pd
from sklearn.ensemble import HistGradientBoostingClassifier

FEATURES = [
    "ret_1", "ret_3", "ret_5", "ret_10", "ret_20",
    "rsi", "ema_ratio", "macd_h", "bb_pos", "atr_pct",
    "vol_z", "range_pct", "trend_dist", "hour_sin", "hour_cos",
]


def build_features(df: pd.DataFrame) -> pd.DataFrame:
    d = df.copy()
    c, h, l, v = d["close"], d["high"], d["low"], d["volume"]

    for n in (1, 3, 5, 10, 20):
        d[f"ret_{n}"] = c.pct_change(n)

    delta = c.diff()
    up = delta.clip(lower=0).ewm(alpha=1 / 14, adjust=False).mean()
    down = (-delta.clip(upper=0)).ewm(alpha=1 / 14, adjust=False).mean()
    d["rsi"] = 100 - 100 / (1 + up / (down + 1e-12))

    ema_f = c.ewm(span=12, adjust=False).mean()
    ema_s = c.ewm(span=26, adjust=False).mean()
    d["ema_ratio"] = ema_f / ema_s - 1
    macd = ema_f - ema_s
    d["macd_h"] = (macd - macd.ewm(span=9, adjust=False).mean()) / c

    ma20, sd20 = c.rolling(20).mean(), c.rolling(20).std()
    d["bb_pos"] = (c - ma20) / (2 * sd20 + 1e-12)

    prev = c.shift()
    tr = pd.concat([h - l, (h - prev).abs(), (l - prev).abs()], axis=1).max(axis=1)
    d["atr"] = tr.rolling(14).mean()
    d["atr_pct"] = d["atr"] / c
    d["range_pct"] = (h - l) / c
    d["vol_z"] = (v - v.rolling(48).mean()) / (v.rolling(48).std() + 1e-12)

    d["ema_trend"] = c.ewm(span=50, adjust=False).mean()
    d["trend_dist"] = c / d["ema_trend"] - 1

    hours = pd.to_datetime(d["ts"], unit="ms", utc=True).dt.hour
    d["hour_sin"] = np.sin(2 * np.pi * hours / 24)
    d["hour_cos"] = np.cos(2 * np.pi * hours / 24)
    return d.replace([np.inf, -np.inf], np.nan)


class PriceModel:
    def __init__(self, horizon: int, min_val_accuracy: float, buy_threshold: float):
        self.horizon = horizon
        self.min_val_accuracy = min_val_accuracy
        self.buy_threshold = buy_threshold
        self.model = None
        self.stats: dict = {}

    @staticmethod
    def _new():
        return HistGradientBoostingClassifier(
            max_depth=3, learning_rate=0.05, max_iter=150,
            min_samples_leaf=30, l2_regularization=1.0, random_state=42,
        )

    @property
    def ok(self) -> bool:
        return bool(self.stats) and self.stats["val_acc"] >= self.min_val_accuracy

    def fit(self, df: pd.DataFrame) -> dict:
        d = build_features(df)
        d["y"] = (d["close"].shift(-self.horizon) > d["close"]).astype(int)
        d = d.iloc[: -self.horizon].dropna(subset=FEATURES)  # last rows have no known outcome yet
        if len(d) < 250:
            raise ValueError(f"only {len(d)} usable candles, need at least 250")

        X, y = d[FEATURES].to_numpy(float), d["y"].to_numpy()
        split = int(len(d) * 0.8)
        gap = self.horizon  # keep a gap so validation never overlaps training labels
        m = self._new().fit(X[: split - gap], y[: split - gap])
        pv = m.predict_proba(X[split:])[:, 1]
        yv = y[split:]

        conf = pv >= self.buy_threshold
        self.stats = {
            "val_acc": float(((pv > 0.5) == yv).mean()),
            "baseline": float(max(yv.mean(), 1 - yv.mean())),
            "n_train": int(split - gap),
            "n_val": int(len(yv)),
            "conf_n": int(conf.sum()),
            "conf_hit": float(yv[conf].mean()) if conf.any() else None,
            "trained_at": time.time(),
        }
        self.model = self._new().fit(X, y)  # final model uses all data
        return self.stats

    def predict(self, df: pd.DataFrame) -> dict:
        d = build_features(df)
        row = d.iloc[-1]
        if row[FEATURES].isna().any():
            raise ValueError("not enough history to compute indicators")
        x = row[FEATURES].to_numpy(float).reshape(1, -1)
        close = float(row["close"])
        return {
            "prob_up": float(self.model.predict_proba(x)[0, 1]),
            "close": close,
            "atr": float(row["atr"]),
            "atr_pct": float(row["atr"] / close),
            "rsi": float(row["rsi"]),
            "ema_ratio": float(row["ema_ratio"]),
            "macd_h": float(row["macd_h"]),
            "bb_pos": float(row["bb_pos"]),
            "vol_z": float(row["vol_z"]),
            "trend_dist": float(row["trend_dist"]),
            "trend_ok": bool(close > row["ema_trend"]),
        }
