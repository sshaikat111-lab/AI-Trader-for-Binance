"""Offline self-test. Runs the whole bot on fake data and a fake Gemini server. No internet or API keys needed.
Run:  python smoke_test.py
"""
import json
import os
import tempfile
import threading
import time
from http.server import BaseHTTPRequestHandler, HTTPServer

os.environ.update(TRADING_MODE="paper", DATA_SOURCE="synthetic", STATE_DIR=tempfile.mkdtemp(),
                  STRATEGY="ml", GEMINI_API_KEY="", BINANCE_API_KEY="", BINANCE_API_SECRET="")

from bot import TradingBot
from broker import PaperBroker
from config import load_config
from data import SyntheticData
from gemini import GeminiAnalyst, GeminiError, GeminiUnavailable

PASSED = []


def ok(name):
    PASSED.append(name)
    print(f"  ok  {name}")


# ---------------------------------------------------------------- fake Gemini server
class Mock(BaseHTTPRequestHandler):
    mode = "normal"
    bodies: list = []

    def log_message(self, *a):
        pass

    def _send(self, code, obj):
        raw = json.dumps(obj).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def do_POST(self):
        body = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
        Mock.bodies.append(body)
        if self.headers.get("x-goog-api-key") != "test-key":
            return self._send(403, {"error": {"message": "bad key"}})
        prompt = body["contents"][0]["parts"][0]["text"]
        holding = "HOLDING" in prompt
        m = Mock.mode
        if m == "slow":
            time.sleep(6)
        if m == "429":
            return self._send(429, {"error": {"message": "quota", "details": [{"retryDelay": "30s"}]}})
        if m == "429day":
            return self._send(429, {"error": {"message": "exceeded PerDay quota"}})
        if m == "500":
            return self._send(503, {"error": {"message": "overloaded"}})
        if m == "schema400" and "responseSchema" in body["generationConfig"]:
            return self._send(400, {"error": {"message": "response_schema not supported"}})
        answers = {
            "normal": {"action": "SELL" if holding else "BUY", "confidence": 0.8, "trend": "UP", "reasoning": "mock reason"},
            "weak": {"action": "BUY", "confidence": 0.55, "trend": "UP", "reasoning": "unsure"},
            "hold": {"action": "HOLD", "confidence": 0.7, "trend": "SIDEWAYS", "reasoning": "flat market"},
            "wrongway": {"action": "BUY" if holding else "SELL", "confidence": 0.9, "trend": "UP", "reasoning": "nonsense for state"},
            "percent": {"action": "BUY", "confidence": 82, "trend": "up", "reasoning": "percent style"},
        }
        text = json.dumps(answers.get(m, answers["normal"]))
        if m == "fenced":
            text = "```json\n" + json.dumps(answers["normal"]) + "\n```"
        if m == "garbage":
            text = "I think you should buy!"
        self._send(200, {"candidates": [{"content": {"parts": [{"text": text}]}, "finishReason": "STOP"}]})


server = HTTPServer(("127.0.0.1", 0), Mock)
threading.Thread(target=server.serve_forever, daemon=True).start()
BASE = f"http://127.0.0.1:{server.server_port}"


def analyst(key="test-key", max_calls=100):
    return GeminiAnalyst(key, "gemini-test", BASE, 0, max_calls, 10, tempfile.mkdtemp())


def loosened_cfg():
    cfg = load_config()
    cfg.state_dir = tempfile.mkdtemp()
    cfg.min_val_accuracy, cfg.buy_threshold, cfg.min_atr_pct, cfg.trend_filter = 0.0, 0.5, 0.0, False
    return cfg


def new_bot(strategy, an=None, cfg=None):
    cfg = cfg or loosened_cfg()
    cfg.strategy = strategy
    data = SyntheticData()
    return TradingBot(cfg, data, PaperBroker(data, cfg.paper_start_balance, cfg.fee_rate, cfg.slippage), an), cfg


def payload(holding=False):
    data = SyntheticData()
    df = data.ohlcv("BTC/USDT", "15m", 60).iloc[:-1]
    ind = dict(rsi=55.0, ema_ratio=0.001, macd_h=0.0002, bb_pos=0.3, atr_pct=0.003, vol_z=0.5, trend_dist=0.004)
    return {"symbol": "BTC/USDT", "timeframe": "15m", "price": 60000.0, "round_trip_cost_pct": 0.3,
            "indicators": ind, "ml": {"prob_up": 0.6, "horizon": 3, "val_acc": 0.53, "baseline": 0.51, "reliable": True},
            "position": {"entry": 59900, "stop": 59500, "target": 60700, "pnl_pct": 0.2} if holding else None,
            "candles": df.tail(48)[["ts", "open", "high", "low", "close", "volume"]].values.tolist()}


# ======================================================= 1. statistical model + risk rules
print("1. Statistical model, risk rules, accounting")
bot, cfg = new_bot("ml")
start_equity = bot.equity
bot._tick()
snap = bot.snapshot()
json.dumps(snap)
assert snap["signals"] and snap["strategy"] == "ml" and "gemini" in snap and "modes" in snap
assert "gemini_api_key" not in snap["config"] and "api_secret" not in snap["config"], "secrets must never reach the browser"
ok("signals produced, snapshot is JSON-safe, no secrets exposed")
assert bot.positions
s, pos = next(iter(bot.positions.items()))
assert pos.stop < pos.entry_price < pos.take_profit
assert pos.qty * pos.entry_price <= start_equity * cfg.max_position_pct * 1.01
ok("position sized within caps, stop below entry, target above")
bot.prices[s] = pos.stop * 0.999
bot._check_exits(time.time())
assert s not in bot.positions and bot.trades[-1]["reason"] == "stop_loss" and bot.trades[-1]["pnl"] < 0
ok("stop-loss closes the position at a loss")
bot.day_start_equity = bot.equity * 1.5
bot._check_daily_limit()
assert bot.halted and not bot.positions
ok("daily loss limit halts trading")
bot2, _ = new_bot("ml", cfg=cfg)
assert len(bot2.trades) == len(bot.trades)
ok("state persists across restarts")

# ======================================================= 2. Gemini client
print("2. Gemini client")
Mock.mode, Mock.bodies = "normal", []
a = analyst()
r = a.analyze(payload(False))
assert r["action"] == "BUY" and r["confidence"] == 0.8 and r["trend"] == "UP"
sent = Mock.bodies[-1]
assert "responseSchema" in sent["generationConfig"] and sent["generationConfig"]["responseMimeType"] == "application/json"
assert "FLAT" in sent["contents"][0]["parts"][0]["text"] and "Recent candles" in sent["contents"][0]["parts"][0]["text"]
ok("request is well-formed and answer parsed (BUY when flat)")
assert a.analyze(payload(True))["action"] == "SELL"
ok("holding position -> SELL understood")

for mode, expect in (("fenced", "BUY"), ("percent", "BUY")):
    Mock.mode = mode
    r = analyst().analyze(payload(False))
    assert r["action"] == expect
    if mode == "percent":
        assert abs(r["confidence"] - 0.82) < 1e-9 and r["trend"] == "UP"
ok("tolerates code fences and 0-100 confidence")
Mock.mode = "wrongway"
assert analyst().analyze(payload(False))["action"] == "HOLD" and analyst().analyze(payload(True))["action"] == "HOLD"
ok("impossible actions for a long-only bot become HOLD")
Mock.mode = "garbage"
try:
    analyst().analyze(payload()); raise SystemExit("should fail")
except GeminiError:
    ok("non-JSON answer rejected")
Mock.mode, Mock.bodies = "schema400", []
r = analyst().analyze(payload())
assert r["action"] == "BUY" and "responseSchema" not in Mock.bodies[-1]["generationConfig"] and len(Mock.bodies) == 2
ok("falls back to plain JSON when schema is rejected")
Mock.mode = "429"
a = analyst()
try:
    a.analyze(payload()); raise SystemExit("should fail")
except GeminiUnavailable:
    pass
n = len(Mock.bodies)
try:
    a.analyze(payload())
except GeminiUnavailable as e:
    assert "paused" in str(e) and len(Mock.bodies) == n
ok("429 pauses further calls instead of hammering the API")
Mock.mode = "500"
t0 = time.time()
try:
    analyst().analyze(payload()); raise SystemExit("should fail")
except GeminiUnavailable:
    ok(f"server errors retried then reported ({time.time() - t0:.0f}s)")
Mock.mode = "normal"
try:
    analyst(key="wrong-key").analyze(payload()); raise SystemExit("should fail")
except GeminiError as e:
    assert "API key" in str(e) and "wrong-key" not in str(e)
    ok("bad key gives a clear error and never echoes the key")
a = analyst(max_calls=1)
a.analyze(payload())
try:
    a.analyze(payload()); raise SystemExit("should fail")
except GeminiUnavailable as e:
    assert "daily" in str(e)
    ok("client-side daily cap enforced")
try:
    analyst(key="").analyze(payload())
except GeminiUnavailable:
    ok("no key -> unavailable, no request sent")

# ======================================================= 3. bot + Gemini strategies
print("3. Strategies")
Mock.mode = "normal"
bot, cfg = new_bot("gemini", analyst())
bot._tick()
assert bot.positions, "gemini strategy should have bought"
t = bot.trades[-1]
assert t["side"] == "buy" and t["reason"] == "gemini_signal"
sig = bot.snapshot()["signals"]
assert any(v["gemini"] and v["gemini"]["ok"] and v["action"] == "BUY" for v in sig.values())
ok("gemini strategy: Gemini BUY -> trade placed with gemini_signal reason")
s = next(iter(bot.positions))
model = bot.models[s]
pred = {"prob_up": 0.9, "close": bot.prices[s], "atr": 1.0, "atr_pct": 0.01, "rsi": 50, "trend_ok": True}
bot._decide(s, pred, model, {"ok": True, "action": "SELL", "confidence": 0.8, "trend": "DOWN", "reasoning": "x", "time": 0})
assert s not in bot.positions and bot.trades[-1]["reason"] == "gemini_exit"
ok("gemini strategy: Gemini SELL closes the position")

Mock.mode = "weak"
bot, _ = new_bot("gemini", analyst())
bot._tick()
assert not bot.positions
reasons = " ".join(v["reason"] for v in bot.snapshot()["signals"].values())
assert "only 55%" in reasons and "needs 65%" in reasons
ok("low-confidence Gemini BUY is refused, reason shown")

Mock.mode = "429"
bot, _ = new_bot("gemini", analyst())
bot._tick()
assert not bot.positions
reasons = " ".join(v["reason"] for v in bot.snapshot()["signals"].values())
assert "Gemini unavailable" in reasons
ok("Gemini outage -> no new trades (fails safe)")

Mock.mode, Mock.bodies = "normal", []
cfg = loosened_cfg(); cfg.buy_threshold = 0.999            # model will never pass
bot, _ = new_bot("hybrid", analyst(), cfg)
bot._tick()
assert not bot.positions and len(Mock.bodies) == 0
ok("hybrid: Gemini is not even called when the model already says no (saves free quota)")

Mock.mode, Mock.bodies = "normal", []
bot, _ = new_bot("hybrid", analyst())
bot._tick()
assert bot.positions and bot.trades[-1]["reason"] == "hybrid_signal"
ok("hybrid: model and Gemini agree -> trade")

Mock.mode = "hold"
bot, _ = new_bot("hybrid", analyst())
bot._tick()
assert not bot.positions
ok("hybrid: Gemini says HOLD -> no trade even though the model was willing")

bot, _ = new_bot("gemini", None)
assert bot.strategy == "ml"
try:
    bot.set_strategy("gemini"); raise SystemExit("should fail")
except ValueError:
    ok("no Gemini key -> falls back to the statistical model; switching to Gemini refused")

# a stalled Gemini must never delay stop-losses
Mock.mode = "slow"
cfg = loosened_cfg(); cfg.loop_seconds = 1
bot, _ = new_bot("gemini", analyst(), cfg)
px0 = bot.data.price("BTC/USDT")
bot.prices["BTC/USDT"] = px0
with bot.lock:
    placed, msg = bot._open("BTC/USDT", {"close": px0, "atr": px0 * 0.003}, "gemini_signal")
assert placed, msg
crash = bot.positions["BTC/USDT"].stop * 0.99
bot.data.price = lambda symbol: crash
t0 = time.time()
bot.start()
while "BTC/USDT" in bot.positions and time.time() - t0 < 5:
    time.sleep(0.1)
elapsed = time.time() - t0
assert "BTC/USDT" not in bot.positions and elapsed < 4, f"stop-loss was delayed ({elapsed:.1f}s)"
assert bot._analysis_thread.is_alive(), "test expects Gemini to still be stalled"
ok(f"stop-loss fired in {elapsed:.1f}s while Gemini was stalled for 6s (monitor thread is independent)")
bot.stop()
try:
    bot.start(); raise SystemExit("should refuse")
except RuntimeError:
    ok("cannot restart while the previous step is still finishing")
bot._thread.join(timeout=30); bot._analysis_thread.join(timeout=30)
Mock.mode = "normal"

# ======================================================= 4. mode switching
print("4. Mode switching")
bot, cfg = new_bot("ml")
assert bot.switch_blocker() == ""
bot.start(); assert bot.switch_blocker() and "Stop" in bot.switch_blocker(); bot.stop()
bot._thread.join(timeout=60); bot._analysis_thread.join(timeout=60)
assert not bot.positions, "a stopped bot must not open trades"
ok("cannot switch while running; a stopped bot opens nothing")
bot._stop.clear()      # what start() does
bot._tick()
assert bot.positions and "Sell" in bot.switch_blocker()
try:
    bot.apply_mode("testnet", PaperBroker(bot.data, 500, 0.001, 0)); raise SystemExit("should fail")
except RuntimeError:
    ok("cannot switch while positions are open")
bot.panic()
bot.apply_mode("testnet", PaperBroker(bot.data, 500, 0.001, 0))
assert cfg.mode == "testnet" and bot.equity == 500 and not bot.trades and "testnet" in str(bot.state_file)
assert bot.snapshot()["mode"] == "testnet"
ok("switch applies: separate account, separate history and state file")
bot.apply_mode("paper", PaperBroker(bot.data, cfg.paper_start_balance, 0.001, 0))
assert cfg.mode == "paper" and len(bot.trades) >= 2, "paper history restored"
ok("switching back restores that mode's saved history")

# ======================================================= 5. HTTP API
print("5. HTTP API")
try:
    from fastapi.testclient import TestClient
except Exception:
    print("  skipped (pip install httpx to run the API tests)")
else:
    import importlib
    os.environ.update(STATE_DIR=tempfile.mkdtemp())
    import main
    importlib.reload(main)
    main.cfg.min_val_accuracy = 0.0
    with TestClient(main.app) as c:
        st = c.get("/api/state").json()
        assert st["mode"] == "paper" and not st["modes"]["testnet"]["available"] and st["gemini"]["enabled"] is False
        ok("state exposes mode options and Gemini status")
        r = c.post("/api/mode", json={"mode": "testnet"})
        assert r.status_code == 400 and "Demo data" in r.json()["detail"]
        ok("real accounts refused while demo data is on")
        main.cfg.data_source = "binance"
        r = c.post("/api/mode", json={"mode": "testnet"})
        assert r.status_code == 400 and "BINANCE_API_KEY" in r.json()["detail"]
        ok("testnet without keys -> clear instruction")
        assert c.post("/api/mode", json={"mode": "banana"}).status_code == 400
        assert c.post("/api/strategy", json={"strategy": "gemini"}).status_code == 400
        ok("unknown mode / Gemini without key rejected")
        main.cfg.api_key = main.cfg.api_secret = "fake"
        r = c.post("/api/mode", json={"mode": "live", "confirm": "yes"})
        assert r.status_code == 400 and "I_UNDERSTAND_THE_RISK" in r.json()["detail"]
        ok("live requires the typed confirmation phrase")
        t0 = time.time()
        r = c.post("/api/mode", json={"mode": "testnet"})
        assert r.status_code == 502 and "Could not connect" in r.json()["detail"] and main.cfg.mode == "paper"
        ok(f"unreachable/invalid Binance keys -> clear error, mode unchanged ({time.time() - t0:.0f}s)")
        assert c.post("/api/mode", json={"mode": "paper"}).status_code == 200
        c.post("/api/bot/start")
        assert c.post("/api/mode", json={"mode": "testnet"}).status_code == 409
        ok("cannot switch while the bot is running")
        c.post("/api/bot/stop")
        assert c.post("/api/strategy", json={"strategy": "ml"}).json()["strategy"] == "ml"

print(f"\nALL CHECKS PASSED ({len(PASSED)} assertions groups)")
