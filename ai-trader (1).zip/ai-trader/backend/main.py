"""FastAPI server: exposes the bot to the dashboard and serves the HTML page."""
from __future__ import annotations

import time
from contextlib import asynccontextmanager
from pathlib import Path

import uvicorn
from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from pydantic import BaseModel

from bot import STRATEGIES, TradingBot
from broker import make_broker
from config import LIVE_PHRASE, load_config
from data import make_data
from gemini import GeminiAnalyst

FRONTEND = Path(__file__).resolve().parent.parent / "frontend" / "index.html"
cfg = load_config()
bot: TradingBot | None = None
_candle_cache: dict = {}


@asynccontextmanager
async def lifespan(app: FastAPI):
    global bot
    cfg.validate()
    data = make_data(cfg.data_source)
    broker = make_broker(cfg, data)
    analyst = GeminiAnalyst(cfg.gemini_api_key, cfg.gemini_model, cfg.gemini_base_url, cfg.gemini_min_interval,
                            cfg.gemini_max_calls_per_day, cfg.gemini_timeout, cfg.state_dir)
    bot = TradingBot(cfg, data, broker, analyst)
    app.state.data = data
    banner = {"paper": "PAPER mode (simulated money)", "testnet": "TESTNET mode (fake money)",
              "live": "LIVE mode - REAL MONEY"}[cfg.mode]
    gem = f"Gemini ({cfg.gemini_model})" if analyst.enabled else "no Gemini key"
    print(f"\n  AI Trader ready: {banner}\n  AI engine: {bot.strategy} | {gem}\n  Open http://{cfg.host}:{cfg.port}\n")
    if cfg.auto_start:
        if cfg.mode == "live":
            print("  AUTO_START_BOT is ignored in live mode. Press Start bot in the dashboard.\n")
        else:
            bot.start()
    yield
    bot.stop()


app = FastAPI(title="AI Trader", lifespan=lifespan)


class SymbolBody(BaseModel):
    symbol: str


class ModeBody(BaseModel):
    mode: str
    confirm: str = ""


class StrategyBody(BaseModel):
    strategy: str


def _bot() -> TradingBot:
    if bot is None:
        raise HTTPException(503, "bot is not ready")
    return bot


@app.get("/")
def index():
    return FileResponse(FRONTEND)


@app.get("/api/state")
def state():
    return _bot().snapshot()


@app.get("/api/candles")
def candles(symbol: str, limit: int = 120):
    _bot()
    if symbol not in cfg.symbols:
        raise HTTPException(404, "unknown symbol")
    key = (symbol, limit)
    hit = _candle_cache.get(key)
    if hit and time.time() - hit[0] < 10:
        return hit[1]
    df = app.state.data.ohlcv(symbol, cfg.timeframe, min(max(limit, 20), 500))
    out = {"symbol": symbol, "timeframe": cfg.timeframe,
           "candles": df[["ts", "open", "high", "low", "close"]].values.tolist()}
    _candle_cache[key] = (time.time(), out)
    return out


@app.post("/api/bot/start")
def start():
    try:
        _bot().start()
    except RuntimeError as e:
        raise HTTPException(409, str(e))
    return {"ok": True}


@app.post("/api/bot/stop")
def stop():
    _bot().stop()
    return {"ok": True}


@app.post("/api/mode")
def change_mode(body: ModeBody):
    """Switch between paper / testnet / live. Keys always come from .env, never from the browser."""
    b = _bot()
    mode = body.mode.strip().lower()
    if mode not in ("paper", "testnet", "live"):
        raise HTTPException(400, "unknown mode")
    if mode == cfg.mode:
        return {"ok": True, "mode": mode}
    blocked = b.switch_blocker()
    if blocked:
        raise HTTPException(409, blocked)
    if mode in ("testnet", "live"):
        opt = b._mode_options()[mode]
        if not opt["available"]:
            raise HTTPException(400, opt["reason"])
    if mode == "live" and body.confirm.strip() != LIVE_PHRASE:
        raise HTTPException(400, f"To use real money, type the phrase {LIVE_PHRASE} exactly.")
    try:
        broker = make_broker(cfg, app.state.data, mode)
        if mode != "paper":
            broker.quote_balance()          # proves the keys work before we switch
    except Exception as e:
        raise HTTPException(502, f"Could not connect to Binance {mode}: {str(e)[:300]}")
    try:
        b.apply_mode(mode, broker)
    except RuntimeError as e:
        raise HTTPException(409, str(e))
    return {"ok": True, "mode": mode}


@app.post("/api/strategy")
def change_strategy(body: StrategyBody):
    if body.strategy not in STRATEGIES:
        raise HTTPException(400, "unknown AI engine")
    try:
        _bot().set_strategy(body.strategy)
    except ValueError as e:
        raise HTTPException(400, str(e))
    return {"ok": True, "strategy": body.strategy}


@app.post("/api/positions/close")
def close_position(body: SymbolBody):
    try:
        _bot().close_position(body.symbol)
    except KeyError as e:
        raise HTTPException(404, str(e))
    except Exception as e:
        raise HTTPException(500, f"Could not close position: {e}")
    return {"ok": True}


@app.post("/api/panic")
def panic():
    try:
        _bot().panic()
    except Exception as e:
        raise HTTPException(500, str(e))
    return {"ok": True}


@app.post("/api/paper/reset")
def reset_paper():
    try:
        _bot().reset_paper()
    except Exception as e:
        raise HTTPException(400, str(e))
    return {"ok": True}


if __name__ == "__main__":
    uvicorn.run("main:app", host=cfg.host, port=cfg.port, log_level="warning")
